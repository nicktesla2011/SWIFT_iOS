//: Playground - noun: a place where people can play

import UIKit

/* 
 
 Swift uses 3 types of collections
 Arrays 
 Sets 
 Dictionaries
 
 This is an example of an Array
 
 An array stores values of the same type in an ordered list. The same value can appear in an array multiple times at different positions. */

 var myArray = [12,11,56,10]
//var myArray: [Int] = [1,4,5]

print (myArray)
print (myArray.count)
print (myArray[1])
print (myArray[3])


var myStringArray = ["Apple", "Grapes", "Lemons"]

print (myStringArray.count)
print (myStringArray[2])


//Append adds to existing array
myStringArray.append("Bread")
print (myStringArray)

myArray.append(7)
myStringArray += ["Hello"]

//add items at a particular index
myStringArray.insert("cars", atIndex: 0)


//Remove items from an array.
myStringArray.removeAtIndex(2)
print(myStringArray)


myStringArray.removeLast()
print (myStringArray)


var myPrices : [Double] = [1.25,3.25,4.25]
print (myPrices)
